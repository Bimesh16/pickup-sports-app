package com.bmessi.pickupsportsapp.security;

public enum Role {
    USER,
    ORGANIZER,
    ADMIN
}
