package com.bmessi.pickupsportsapp.exception;

public class WaitlistServiceException extends RuntimeException {
    public WaitlistServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}
