package com.bmessi.pickupsportsapp.dto.api;

public record EnabledResponse(boolean enabled) {}
