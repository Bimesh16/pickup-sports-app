package com.bmessi.pickupsportsapp.dto.api;

public record EnrollResponse(String secret, String otpauth) {}
