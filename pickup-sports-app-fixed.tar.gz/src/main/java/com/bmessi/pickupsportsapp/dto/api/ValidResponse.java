package com.bmessi.pickupsportsapp.dto.api;

public record ValidResponse(boolean valid) {}
