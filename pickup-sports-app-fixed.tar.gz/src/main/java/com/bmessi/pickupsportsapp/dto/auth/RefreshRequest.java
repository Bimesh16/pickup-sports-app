package com.bmessi.pickupsportsapp.dto.auth;

import jakarta.validation.constraints.NotBlank;

public record RefreshRequest(
        @NotBlank String refreshToken,
        String nonce
) {}