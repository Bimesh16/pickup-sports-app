package com.bmessi.pickupsportsapp.dto.api;

public record CountResponse(long count) {}
