package com.bmessi.pickupsportsapp.dto.api;

public record PresignResponse(String putUrl, String getUrl, String key, String relativePath) {}
