package com.bmessi.pickupsportsapp.dto.api;

public record ReplaceResultResponse(String message, int count) {}
