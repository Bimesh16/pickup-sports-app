package com.bmessi.pickupsportsapp.dto.api;

public record UpdatedResponse(int updated) {}
