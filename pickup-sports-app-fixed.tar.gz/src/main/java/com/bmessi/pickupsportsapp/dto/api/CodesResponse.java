package com.bmessi.pickupsportsapp.dto.api;

import java.util.List;

public record CodesResponse(List<String> codes, int count) {}
