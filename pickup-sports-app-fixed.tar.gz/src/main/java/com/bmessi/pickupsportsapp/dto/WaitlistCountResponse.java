package com.bmessi.pickupsportsapp.dto;

public record WaitlistCountResponse(int count) {}
