package com.bmessi.pickupsportsapp.dto.api;

import java.util.List;

public record WordsResponse(int count, List<String> words) {}
