package com.bmessi.pickupsportsapp.dto.api;

public record StatusResponse(String status) {}
