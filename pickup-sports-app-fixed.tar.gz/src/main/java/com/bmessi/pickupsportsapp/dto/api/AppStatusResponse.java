package com.bmessi.pickupsportsapp.dto.api;

public record AppStatusResponse(String app, String version, String status, long timestamp) {}
