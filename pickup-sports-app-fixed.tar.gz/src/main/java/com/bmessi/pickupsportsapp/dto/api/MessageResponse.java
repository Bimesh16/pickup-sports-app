package com.bmessi.pickupsportsapp.dto.api;

public record MessageResponse(String message) {}
