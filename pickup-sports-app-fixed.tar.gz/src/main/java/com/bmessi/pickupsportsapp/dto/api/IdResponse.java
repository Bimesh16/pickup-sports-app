package com.bmessi.pickupsportsapp.dto.api;

public record IdResponse(Long id) {}
